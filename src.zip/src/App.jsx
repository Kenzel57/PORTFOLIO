import Home from "./pages/Home";
import Projects from "./pages/Projects/Projects";
import Category from "./pages/Category/Category";
import About from "./pages/About/About";

export default function App() {
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  const parts = path.split("/").filter(Boolean);

  if (path === "/") return <Home />;

  // /work is kept so the links we already wrote keep working
  if (path === "/work" || path === "/projects") return <Projects />;

  // /work/weddings -> the category page
  if (parts[0] === "work" && parts.length === 2) {
    return <Category slug={parts[1]} />;
  }

  // Next pages, once we build them:
  // if (parts[0] === "work" && parts.length === 3) return <Film />;
  if (path === "/about") return <About />;

  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#000",
        color: "#fff",
      }}
    >
      <a href="/">Back home</a>
    </main>
  );
}