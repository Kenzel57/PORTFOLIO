const names = [
  "Golden Hour", "First Dance", "After the Rain", "Slow Motion",
  "Open Road", "Late Light", "The Toast", "Midnight",
  "Sunday Film", "Quiet Hours", "Bright Side", "Last Song",
];
const types = ["Commercial", "Narrative", "Music"];

export function getFilms(cat) {
  const count = Math.min(12, parseInt(cat.meta, 10) || 9);

  return Array.from({ length: count }, (_, i) => {
    const ep = String(((cat.id + i) % 10) + 1).padStart(2, "0");
    return {
      n: String(i + 1).padStart(2, "0"),
      title: names[i % names.length],
      type: types[i % types.length],
      video: `/videos/work/s06e${ep}.mp4`,
    };
  });
}