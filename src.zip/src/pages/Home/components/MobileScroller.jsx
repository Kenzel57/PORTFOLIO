import { useEffect, useRef } from "react";

function Slide({ clip, isActive, isNear, postersOnly }) {
  const ref = useRef(null);

  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    if (isActive) {
      v.currentTime = 0;
      v.play().catch(() => {});
    } else {
      v.pause();
    }
  }, [isActive, isNear]);

  return (
    <section className="relative h-full w-full shrink-0 snap-start snap-always overflow-hidden bg-black">
      {/* poster sits under the video so there is never a black flash */}
      <img
        src={clip.poster}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      {isNear && !postersOnly && (
        <video
          ref={ref}
          src={clip.mobile}
          muted
          loop
          playsInline
          preload="auto"
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}
    </section>
  );
}

export default function MobileScroller({
  clips,
  activeIndex,
  onIndexChange,
  postersOnly,
}) {
  const ref = useRef(null);
  const raf = useRef(0);

  // If the screen was rotated/resized, jump to the current clip
  useEffect(() => {
    const el = ref.current;
    el.scrollTop = activeIndex * el.clientHeight;
    return () => cancelAnimationFrame(raf.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onScroll = () => {
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(() => {
      const el = ref.current;
      if (!el) return;
      const i = Math.min(
        clips.length - 1,
        Math.max(0, Math.round(el.scrollTop / el.clientHeight))
      );
      if (i !== activeIndex) onIndexChange(i);
    });
  };

  return (
    <div
      ref={ref}
      onScroll={onScroll}
      className="absolute inset-0 z-0 snap-y snap-mandatory overflow-y-scroll overscroll-y-contain [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
    >
      {clips.map((clip, i) => (
        <Slide
          key={clip.id}
          clip={clip}
          isActive={i === activeIndex}
          isNear={Math.abs(i - activeIndex) <= 1}
          postersOnly={postersOnly}
        />
      ))}
    </div>
  );
}