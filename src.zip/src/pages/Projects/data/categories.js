// d = desktop layout: row, starting column (1-12), width in columns, top offset in px
// m = mobile layout: width % of screen, left offset %, top offset in px
// Files go in /public: videos/work/<slug>.mp4 and posters/work/<slug>.jpg
export const categories = [
  { id: 1, slug: "weddings", title: "Weddings", meta: "24 films", aspect: "16/9", autoplay: true,
    d: { row: 1, col: 1, span: 4, mt: 0 }, m: { w: 62, x: 0, mt: 0 } },
  { id: 2, slug: "conferences", title: "Conferences", meta: "18 films", aspect: "16/10", autoplay: false,
    d: { row: 1, col: 7, span: 6, mt: 64 }, m: { w: 68, x: 32, mt: 48 } },

  { id: 3, slug: "hotels", title: "Hotels & Resorts", meta: "12 films", aspect: "3/4", autoplay: true,
    d: { row: 2, col: 2, span: 3, mt: 40 }, m: { w: 48, x: 6, mt: 56 } },
  { id: 4, slug: "concerts", title: "Concerts", meta: "15 films", aspect: "16/9", autoplay: true,
    d: { row: 2, col: 7, span: 5, mt: 140 }, m: { w: 70, x: 30, mt: 48 } },

  { id: 5, slug: "corporate-events", title: "Corporate Events", meta: "20 films", aspect: "16/9", autoplay: false,
    d: { row: 3, col: 1, span: 5, mt: 0 }, m: { w: 64, x: 4, mt: 56 } },
  { id: 6, slug: "birthdays", title: "Birthdays", meta: "9 films", aspect: "1/1", autoplay: true,
    d: { row: 3, col: 9, span: 3, mt: 90 }, m: { w: 46, x: 54, mt: 48 } },

  { id: 7, slug: "festivals", title: "Festivals", meta: "11 films", aspect: "16/9", autoplay: true,
    d: { row: 4, col: 3, span: 6, mt: 30 }, m: { w: 78, x: 10, mt: 56 } },
  { id: 8, slug: "restaurants", title: "Restaurants & Food", meta: "14 films", aspect: "4/5", autoplay: false,
    d: { row: 4, col: 10, span: 3, mt: 0 }, m: { w: 50, x: 0, mt: 48 } },

  { id: 9, slug: "fashion", title: "Fashion", meta: "16 films", aspect: "4/5", autoplay: true,
    d: { row: 5, col: 1, span: 3, mt: 60 }, m: { w: 52, x: 48, mt: 56 } },
  { id: 10, slug: "real-estate", title: "Real Estate", meta: "10 films", aspect: "16/9", autoplay: false,
    d: { row: 5, col: 6, span: 5, mt: 0 }, m: { w: 66, x: 6, mt: 48 } },

  { id: 11, slug: "music-videos", title: "Music Videos", meta: "13 films", aspect: "16/9", autoplay: true,
    d: { row: 6, col: 2, span: 4, mt: 20 }, m: { w: 70, x: 30, mt: 56 } },
  { id: 12, slug: "product-launches", title: "Product Launches", meta: "8 films", aspect: "1/1", autoplay: true,
    d: { row: 6, col: 8, span: 4, mt: 110 }, m: { w: 54, x: 4, mt: 48 } },
].map((c, i) => ({
  ...c,
  video: `/videos/work/s06e${String((i % 10) + 1).padStart(2, "0")}.mp4`,
  poster: `/posters/work/${c.slug}.jpg`,
}));